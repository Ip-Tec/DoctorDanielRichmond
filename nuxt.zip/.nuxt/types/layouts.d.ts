import { ComputedRef, Ref } from 'vue'
export type LayoutKey = "sss-default" | "ssss-cloan" | "testimonial" | "default"
declare module "C:/xampp/htdocs/Website/DoctorDanielRichmond/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    layout?: false | LayoutKey | Ref<LayoutKey> | ComputedRef<LayoutKey>
  }
}