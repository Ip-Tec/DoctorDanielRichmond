import"./entry.7aed8200.js";const r=""+new URL("eyewear-4071870_640.b54fb6fc.jpg",import.meta.url).href;export{r as i};
