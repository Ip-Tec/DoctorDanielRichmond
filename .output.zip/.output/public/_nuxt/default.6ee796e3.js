import{_,x as t}from"./entry.7aed8200.js";const a={};function d(e,f){return t(e.$slots,"default",{},void 0,!0)}const s=_(a,[["render",d],["__scopeId","data-v-f55aadf3"]]);export{s as default};
