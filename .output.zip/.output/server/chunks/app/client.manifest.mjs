const client_manifest = {
  "Header.css": {
    "resourceType": "style",
    "file": "Header.87db88d4.css",
    "src": "Header.css"
  },
  "_Header.f45b15ae.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "Header.87db88d4.css"
    ],
    "file": "Header.f45b15ae.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Header.87db88d4.css": {
    "file": "Header.87db88d4.css",
    "resourceType": "style"
  },
  "_eyewear-4071870_640.34b8a420.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "eyewear-4071870_640.b54fb6fc.jpg"
    ],
    "file": "eyewear-4071870_640.34b8a420.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "eyewear-4071870_640.b54fb6fc.jpg": {
    "file": "eyewear-4071870_640.b54fb6fc.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "assets/img/Testimonial/boy-2119178_640.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "boy-2119178_640.2b3d272f.jpg",
    "src": "assets/img/Testimonial/boy-2119178_640.jpg"
  },
  "assets/img/Testimonial/closeup-1434850_640.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "closeup-1434850_640.1c2167a9.jpg",
    "src": "assets/img/Testimonial/closeup-1434850_640.jpg"
  },
  "assets/img/Testimonial/eyewear-4071870_640.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "eyewear-4071870_640.b54fb6fc.jpg",
    "src": "assets/img/Testimonial/eyewear-4071870_640.jpg"
  },
  "assets/img/Testimonial/face-5084530_1280.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "face-5084530_1280.ba9eb88c.jpg",
    "src": "assets/img/Testimonial/face-5084530_1280.jpg"
  },
  "assets/img/Testimonial/guy-3237859_640.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "guy-3237859_640.f3ca8300.png",
    "src": "assets/img/Testimonial/guy-3237859_640.png"
  },
  "assets/img/Testimonial/istockphoto-1035989300-612x612.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "istockphoto-1035989300-612x612.31adb96f.jpg",
    "src": "assets/img/Testimonial/istockphoto-1035989300-612x612.jpg"
  },
  "assets/img/Testimonial/istockphoto-517925085-612x612.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "istockphoto-517925085-612x612.c0e9da38.jpg",
    "src": "assets/img/Testimonial/istockphoto-517925085-612x612.jpg"
  },
  "assets/img/Testimonial/model-2333408_640.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "model-2333408_640.84206f94.jpg",
    "src": "assets/img/Testimonial/model-2333408_640.jpg"
  },
  "assets/img/Testimonial/portrait-2150880_640.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "portrait-2150880_640.d5daa8f9.jpg",
    "src": "assets/img/Testimonial/portrait-2150880_640.jpg"
  },
  "assets/img/Testimonial/portrait-3518462_640.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "portrait-3518462_640.5e6fc5cd.jpg",
    "src": "assets/img/Testimonial/portrait-3518462_640.jpg"
  },
  "assets/img/Testimonial/young-5200691_640.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "young-5200691_640.380cf371.jpg",
    "src": "assets/img/Testimonial/young-5200691_640.jpg"
  },
  "assets/img/benefits-ayurvedic-healing-herbs.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "benefits-ayurvedic-healing-herbs.f91aed27.jpg",
    "src": "assets/img/benefits-ayurvedic-healing-herbs.jpg"
  },
  "assets/img/herbal-medicine-with-plants-assortment-high-angle.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "herbal-medicine-with-plants-assortment-high-angle.7b621909.jpg",
    "src": "assets/img/herbal-medicine-with-plants-assortment-high-angle.jpg"
  },
  "assets/img/logo.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "logo.d84fb054.jpg",
    "src": "assets/img/logo.jpg"
  },
  "assets/img/organic-herbs-spices-wooden-bowl-generated-by-ai.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "organic-herbs-spices-wooden-bowl-generated-by-ai.330f9735.jpg",
    "src": "assets/img/organic-herbs-spices-wooden-bowl-generated-by-ai.jpg"
  },
  "components/icon/Certified.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Certified.25435891.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Certified.vue"
  },
  "components/icon/Delivery.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Delivery.da598909.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Delivery.vue"
  },
  "components/icon/Doctor.css": {
    "resourceType": "style",
    "file": "Doctor.966e82b8.css",
    "src": "components/icon/Doctor.css"
  },
  "components/icon/Doctor.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "Doctor.49854a3d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Doctor.vue"
  },
  "Doctor.966e82b8.css": {
    "file": "Doctor.966e82b8.css",
    "resourceType": "style"
  },
  "components/icon/Doctors.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Doctors.e0fcaf33.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Doctors.vue"
  },
  "components/icon/Facebook.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Facebook.ada7e4c3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Facebook.vue"
  },
  "components/icon/Medicine.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Medicine.88885172.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Medicine.vue"
  },
  "components/icon/Paypal.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Paypal.327f7fad.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Paypal.vue"
  },
  "components/icon/Squarecash.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Squarecash.01dec4c9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Squarecash.vue"
  },
  "components/icon/Venmo.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Venmo.e0cbe893.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Venmo.vue"
  },
  "components/icon/Whatsapp.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Whatsapp.8f4f884b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Whatsapp.vue"
  },
  "components/icon/Zelle.css": {
    "resourceType": "style",
    "file": "Zelle.fabbed85.css",
    "src": "components/icon/Zelle.css"
  },
  "components/icon/Zelle.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "Zelle.082cd49d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "components/icon/Zelle.vue"
  },
  "Zelle.fabbed85.css": {
    "file": "Zelle.fabbed85.css",
    "resourceType": "style"
  },
  "layouts/SSSDefault.css": {
    "resourceType": "style",
    "file": "SSSDefault.49f7e4a5.css",
    "src": "layouts/SSSDefault.css"
  },
  "layouts/SSSDefault.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "organic-herbs-spices-wooden-bowl-generated-by-ai.330f9735.jpg"
    ],
    "css": [],
    "file": "SSSDefault.78962ac0.js",
    "imports": [
      "_Header.f45b15ae.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/SSSDefault.vue"
  },
  "SSSDefault.49f7e4a5.css": {
    "file": "SSSDefault.49f7e4a5.css",
    "resourceType": "style"
  },
  "organic-herbs-spices-wooden-bowl-generated-by-ai.330f9735.jpg": {
    "file": "organic-herbs-spices-wooden-bowl-generated-by-ai.330f9735.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "layouts/SSSSCloan.css": {
    "resourceType": "style",
    "file": "SSSSCloan.e215d42c.css",
    "src": "layouts/SSSSCloan.css"
  },
  "layouts/SSSSCloan.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "SSSSCloan.85924b27.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/SSSSCloan.vue"
  },
  "SSSSCloan.e215d42c.css": {
    "file": "SSSSCloan.e215d42c.css",
    "resourceType": "style"
  },
  "layouts/Testimonial.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Testimonial.d2ab18e3.js",
    "imports": [
      "_Header.f45b15ae.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/Testimonial.vue"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "file": "default.5d5387f8.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "benefits-ayurvedic-healing-herbs.f91aed27.jpg"
    ],
    "css": [],
    "file": "default.6ee796e3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.5d5387f8.css": {
    "file": "default.5d5387f8.css",
    "resourceType": "style"
  },
  "benefits-ayurvedic-healing-herbs.f91aed27.jpg": {
    "file": "benefits-ayurvedic-healing-herbs.f91aed27.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.38f07c32.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo.d84fb054.jpg"
    ],
    "css": [
      "entry.38f07c32.css"
    ],
    "dynamicImports": [
      "layouts/SSSDefault.vue",
      "layouts/SSSSCloan.vue",
      "layouts/Testimonial.vue",
      "layouts/default.vue"
    ],
    "file": "entry.7aed8200.js",
    "isDynamicEntry": true,
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.38f07c32.css": {
    "file": "entry.38f07c32.css",
    "resourceType": "style"
  },
  "logo.d84fb054.jpg": {
    "file": "logo.d84fb054.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/Store.vue": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "file": "Store.8c23c558.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Store.vue"
  },
  "pages/Testimonial.css": {
    "resourceType": "style",
    "file": "Testimonial.1843ac76.css",
    "src": "pages/Testimonial.css"
  },
  "pages/Testimonial.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "closeup-1434850_640.1c2167a9.jpg",
      "istockphoto-517925085-612x612.c0e9da38.jpg",
      "istockphoto-1035989300-612x612.31adb96f.jpg",
      "portrait-3518462_640.5e6fc5cd.jpg",
      "portrait-2150880_640.d5daa8f9.jpg",
      "young-5200691_640.380cf371.jpg"
    ],
    "css": [],
    "dynamicImports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "file": "Testimonial.c5e9dcd0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_eyewear-4071870_640.34b8a420.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Testimonial.vue"
  },
  "Testimonial.1843ac76.css": {
    "file": "Testimonial.1843ac76.css",
    "resourceType": "style"
  },
  "closeup-1434850_640.1c2167a9.jpg": {
    "file": "closeup-1434850_640.1c2167a9.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "istockphoto-517925085-612x612.c0e9da38.jpg": {
    "file": "istockphoto-517925085-612x612.c0e9da38.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "istockphoto-1035989300-612x612.31adb96f.jpg": {
    "file": "istockphoto-1035989300-612x612.31adb96f.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "portrait-3518462_640.5e6fc5cd.jpg": {
    "file": "portrait-3518462_640.5e6fc5cd.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "portrait-2150880_640.d5daa8f9.jpg": {
    "file": "portrait-2150880_640.d5daa8f9.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "young-5200691_640.380cf371.jpg": {
    "file": "young-5200691_640.380cf371.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.5fabe5d7.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "face-5084530_1280.ba9eb88c.jpg",
      "guy-3237859_640.f3ca8300.png",
      "model-2333408_640.84206f94.jpg",
      "boy-2119178_640.2b3d272f.jpg",
      "benefits-ayurvedic-healing-herbs.f91aed27.jpg",
      "herbal-medicine-with-plants-assortment-high-angle.7b621909.jpg",
      "organic-herbs-spices-wooden-bowl-generated-by-ai.330f9735.jpg"
    ],
    "css": [],
    "dynamicImports": [
      "components/icon/Facebook.vue",
      "components/icon/Whatsapp.vue",
      "components/icon/Venmo.vue",
      "components/icon/Zelle.vue",
      "components/icon/Paypal.vue",
      "components/icon/Squarecash.vue",
      "components/icon/Delivery.vue",
      "components/icon/Certified.vue",
      "components/icon/Doctor.vue",
      "components/icon/Doctors.vue",
      "components/icon/Medicine.vue"
    ],
    "file": "index.11e3faa1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Header.f45b15ae.js",
      "_eyewear-4071870_640.34b8a420.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.5fabe5d7.css": {
    "file": "index.5fabe5d7.css",
    "resourceType": "style"
  },
  "face-5084530_1280.ba9eb88c.jpg": {
    "file": "face-5084530_1280.ba9eb88c.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "guy-3237859_640.f3ca8300.png": {
    "file": "guy-3237859_640.f3ca8300.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "model-2333408_640.84206f94.jpg": {
    "file": "model-2333408_640.84206f94.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "boy-2119178_640.2b3d272f.jpg": {
    "file": "boy-2119178_640.2b3d272f.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "herbal-medicine-with-plants-assortment-high-angle.7b621909.jpg": {
    "file": "herbal-medicine-with-plants-assortment-high-angle.7b621909.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/joinus.css": {
    "resourceType": "style",
    "file": "joinus.fc452a2c.css",
    "src": "pages/joinus.css"
  },
  "pages/joinus.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "benefits-ayurvedic-healing-herbs.f91aed27.jpg"
    ],
    "css": [],
    "file": "joinus.62d3c287.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/joinus.vue"
  },
  "joinus.fc452a2c.css": {
    "file": "joinus.fc452a2c.css",
    "resourceType": "style"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
