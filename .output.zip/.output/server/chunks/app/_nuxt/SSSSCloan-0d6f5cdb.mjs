import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'h3';
import 'ufo';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ id: "parallax-world-of-ugg" }, _attrs))} data-v-8b3471b7><section data-v-8b3471b7><div class="title" data-v-8b3471b7><h3 data-v-8b3471b7>Let&#39;s do some</h3><h1 data-v-8b3471b7>PARALLAX</h1></div></section><section data-v-8b3471b7><div class="parallax-one" data-v-8b3471b7><h2 data-v-8b3471b7>SOUTHERN CALIFORNIA</h2></div></section><section data-v-8b3471b7><div class="block" data-v-8b3471b7><p data-v-8b3471b7><span class="first-character sc" data-v-8b3471b7>I</span>n 1978, Brian Smith landed in Southern California with a bag of sheepskin boots and hope. He fell in love with the sheepskin experience and was convinced the world would one day share this love. The beaches of Southern California had long been an epicenter of a relaxed, casual lifestyle, a lifestyle that Brian felt was a perfect fit for his brand. So he founded the UGG brand, began selling his sheepskin boots and they were an immediate sensation. By the mid 1980&#39;s, the UGG brand became a symbol of relaxed southern California culture, gaining momentum through surf shops and other shops up and down the coast of California, from San Diego to Santa Cruz. UGG boots reached beyond the beach, popping up in big cities and small towns all over, and in every level of society. Girls wore their surfer boyfriend&#39;s pair of UGG boots like a letterman jacket. When winter came along, UGG boots were in ski shops and were seen in lodges from Mammoth to Aspen.</p><p class="line-break margin-top-10" data-v-8b3471b7></p><p class="margin-top-10" data-v-8b3471b7>The UGG brand began to symbolize those who embraced sport and a relaxed, active lifestyle. More than that, an emotional connection and a true feeling of love began to grow for UGG boots, just as Brian had envisioned. People didn&#39;t just like wearing UGG boots, they fell in love with them and literally could not take them off. By the end of the 90&#39;s, celebrities and those in the fashion world took notice of the UGG brand. A cultural shift occurred as well - people were embracing, and feeling empowered, by living a more casual lifestyle and UGG became one of the symbols of this lifestyle. By 2000, a love that began on the beaches had become an icon of casual style. It was at this time that the love for UGG grew in the east, over the Rockies and in Chicago. In 2000, UGG Sheepskin boots were first featured on Oprah&#39;s Favorite Things\xAE and Oprah emphatically declared that she &quot;LOOOOOVES her UGG boots.&quot; From that point on, the world began to notice.</p></div></section><section data-v-8b3471b7><div class="parallax-two" data-v-8b3471b7><h2 data-v-8b3471b7>NEW YORK</h2></div></section><section data-v-8b3471b7><div class="block" data-v-8b3471b7><p data-v-8b3471b7><span class="first-character ny" data-v-8b3471b7>B</span>reaking into the New York fashion world is no easy task. But by the early 2000&#39;s, UGG Australia began to take it by storm. The evolution of UGG from a brand that made sheepskin boots, slippers, clogs and sandals for an active, outdoor lifestyle to a brand that was now being touted as a symbol of a stylish, casual and luxurious lifestyle was swift. Much of this was due to a brand repositioning effort that transformed UGG into a high-end luxury footwear maker. As a fashion brand, UGG advertisements now graced the pages of Vogue Magazine as well as other fashion books. In the mid 2000&#39;s, the desire for premium casual fashion was popping up all over the world and UGG was now perfectly aligned with this movement.</p><p class="line-break margin-top-10" data-v-8b3471b7></p><p class="margin-top-10" data-v-8b3471b7>Fueled by celebrities from coast to coast wearing UGG boots and slippers on their downtime, an entirely new era of fashion was carved out. As a result, the desire and love for UGG increased as people wanted to go deeper into this relaxed UGG experience. UGG began offering numerous color and style variations on their sheepskin boots and slippers. Cold weather boots for women and men and leather casuals were added with great success. What started as a niche item, UGG sheepskin boots were now a must-have staple in everyone&#39;s wardrobe. More UGG collections followed, showcasing everything from knit boots to sneakers to wedges, all the while maintaining that luxurious feel UGG is known for all over the world. UGG products were now seen on runways and in fashion shoots from coast to coast. Before long, the love spread even further.</p></div></section><section data-v-8b3471b7><div class="parallax-three" data-v-8b3471b7><h2 data-v-8b3471b7>ENCHANTED FOREST</h2></div></section><section data-v-8b3471b7><div class="block" data-v-8b3471b7><p data-v-8b3471b7><span class="first-character atw" data-v-8b3471b7>W</span>hen the New York fashion community notices your brand, the world soon follows. The widespread love for UGG extended to Europe in the mid-2000&#39;s along with the stylish casual movement and demand for premium casual fashion. UGG boots and shoes were now seen walking the streets of London, Paris and Amsterdam with regularity. To meet the rising demand from new fans, UGG opened flagship stores in the UK and an additional location in Moscow. As the love spread farther East, concept stores were opened in Beijing, Shanghai and Tokyo. UGG Australia is now an international brand that is loved by all. This love is a result of a magical combination of the amazing functional benefits of sheepskin and the heightened emotional feeling you get when you slip them on your feet. In short, you just feel better all over when you wear UGG boots, slippers, and shoes.</p><p class="line-break margin-top-10" data-v-8b3471b7></p><p class="margin-top-10" data-v-8b3471b7>In 2011, UGG will go back to its roots and focus on bringing the active men that brought the brand to life back with new styles allowing them to love the brand again as well. Partnering with Super Bowl champion and NFL MVP Tom Brady, UGG will invite even more men to feel the love the rest of the world knows so well. UGG will also step into the world of high fashion with UGG Collection. The UGG Collection fuses the timeless craft of Italian shoemaking with the reliable magic of sheepskin, bringing the luxurious feel of UGG to high end fashion. As the love for UGG continues to spread across the world, we have continued to offer new and unexpected ways to experience the brand. The UGG journey continues on and the love for UGG continues to spread.</p></div></section></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/SSSSCloan.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const SSSSCloan = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-8b3471b7"]]);

export { SSSSCloan as default };
//# sourceMappingURL=SSSSCloan-0d6f5cdb.mjs.map
