import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Facebook",
  __ssrInlineRender: true,
  emits: {
    width: {
      type: [String],
      default: "800px"
    },
    height: {
      type: [String],
      default: "800px"
    },
    fill: {
      type: [String],
      default: "none"
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<svg${ssrRenderAttrs(mergeProps({
        width: _ctx.width,
        height: _ctx.height,
        fill: _ctx.fill,
        viewBox: "0 0 32 32",
        xmlns: "http://www.w3.org/2000/svg"
      }, _attrs))}><circle cx="16" cy="16" r="14" fill="url(#paint0_linear_87_7208)"></circle><path d="M21.2137 20.2816L21.8356 16.3301H17.9452V13.767C17.9452 12.6857 18.4877 11.6311 20.2302 11.6311H22V8.26699C22 8.26699 20.3945 8 18.8603 8C15.6548 8 13.5617 9.89294 13.5617 13.3184V16.3301H10V20.2816H13.5617V29.8345C14.2767 29.944 15.0082 30 15.7534 30C16.4986 30 17.2302 29.944 17.9452 29.8345V20.2816H21.2137Z" fill="white"></path><defs><linearGradient id="paint0_linear_87_7208" x1="16" y1="2" x2="16" y2="29.917" gradientUnits="userSpaceOnUse"><stop stop-color="#18ACFE"></stop><stop offset="1" stop-color="#0163E0"></stop></linearGradient></defs></svg>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/icon/Facebook.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=Facebook-9ec2a6d3.mjs.map
