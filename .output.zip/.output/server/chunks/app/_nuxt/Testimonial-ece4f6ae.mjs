import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as _export_sfc, a as __nuxt_component_0 } from '../server.mjs';
import { useSSRContext, defineAsyncComponent } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { i as imge1 } from './eyewear-4071870_640-56d5270e.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import 'unctx';
import 'vue-router';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';

const _imports_0 = "" + buildAssetsURL("closeup-1434850_640.1c2167a9.jpg");
const _imports_2 = "" + buildAssetsURL("istockphoto-517925085-612x612.c0e9da38.jpg");
const _imports_3 = "" + buildAssetsURL("istockphoto-1035989300-612x612.31adb96f.jpg");
const _imports_4 = "" + buildAssetsURL("portrait-3518462_640.5e6fc5cd.jpg");
const _imports_5 = "" + buildAssetsURL("portrait-2150880_640.d5daa8f9.jpg");
const _imports_6 = "" + buildAssetsURL("young-5200691_640.380cf371.jpg");
const __nuxt_component_1_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('../server.mjs').then(function(n) {
  return n.F;
}).then((m) => m.default || m));
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_Navigation = __nuxt_component_0;
  const _component_LazyAppFooter = __nuxt_component_1_lazy;
  _push(`<main${ssrRenderAttrs(_attrs)} data-v-e4b9d542>`);
  _push(ssrRenderComponent(_component_Navigation, null, null, _parent));
  _push(`<h2 data-v-e4b9d542>Testimonial</h2><div class="outerdiv" data-v-e4b9d542><div class="innerdiv" data-v-e4b9d542><div class="div1 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img${ssrRenderAttr("src", _imports_0)} alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name" data-v-e4b9d542>Sophia LP</p><p class="designation" data-v-e4b9d542>Verified clients</p></div></div><div class="review" data-v-e4b9d542><h4 data-v-e4b9d542>Stomach aches.</h4><p data-v-e4b9d542> \u201C Stomach aches, throwing up after eating/drinking, and nausea have affected my daily life, but your herbal remedies have provided me with relief and improved my digestion. I appreciate the holistic approach.\u201D </p></div></div><div class="div2 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img src="https://raw.githubusercontent.com/RahulSahOfficial/testimonials_grid_section/5532c958b7d3c9b910a216b198fdd21c73112d84/images/image-jonathan.jpg" alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name" data-v-e4b9d542>Noah B Walters</p><p class="designation" data-v-e4b9d542>clients</p></div></div><div class="review" data-v-e4b9d542><h4 data-v-e4b9d542>joint popping</h4><p data-v-e4b9d542> \u201C Dealing with joint popping, sensitivity to noise, and anxiety has been challenging, but your herbal products have offered me support and relief. I feel more at ease and comfortable. \u201D </p></div></div><div class="div3 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img${ssrRenderAttr("src", imge1)} alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name dark" data-v-e4b9d542>Kira Whittle</p><p class="designation dark" data-v-e4b9d542>Verified clients</p></div></div><div class="review dark" data-v-e4b9d542><h4 data-v-e4b9d542>Living with MTHFR mutation</h4><p data-v-e4b9d542> \u201C Living with MTHFR mutation can be challenging, but your herbal products have helped me support my methylation process and improve my overall well-being. Thank you for providing natural solutions. \u201D </p></div></div><div class="div4 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img src="https://raw.githubusercontent.com/RahulSahOfficial/testimonials_grid_section/5532c958b7d3c9b910a216b198fdd21c73112d84/images/image-jeanette.jpg" alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name dark" data-v-e4b9d542>David Harmon</p><p class="designation dark" data-v-e4b9d542>Verified clients</p></div></div><div class="review dark" data-v-e4b9d542><h4 data-v-e4b9d542>TMAU</h4><p data-v-e4b9d542> \u201C TMAU has caused embarrassment and social anxiety, but your herbal remedies have helped me manage the symptoms and regain my confidence. I appreciate the holistic approach. \u201D </p></div></div><div class="div5 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img src="https://raw.githubusercontent.com/RahulSahOfficial/testimonials_grid_section/5532c958b7d3c9b910a216b198fdd21c73112d84/images/image-patrick.jpg" alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name" data-v-e4b9d542>Patrick Abrams</p><p class="designation" data-v-e4b9d542>Verified clients</p></div></div><div class="review" data-v-e4b9d542><h4 data-v-e4b9d542>Living with HEDS</h4><p data-v-e4b9d542> \u201C Living with HEDS has meant dealing with joint pain and instability, but your herbal remedies have offered me support and relief. I feel more comfortable and can engage in activities I enjoy \u201D </p></div></div><div class="div6 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img${ssrRenderAttr("src", _imports_2)} alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name dark" data-v-e4b9d542>Natalie C Harmon</p><p class="designation dark" data-v-e4b9d542>Verified clients</p></div></div><div class="review dark" data-v-e4b9d542><h4 data-v-e4b9d542>Living with altered sleep phases</h4><p data-v-e4b9d542> \u201C Living with altered sleep phases and sensitivity to light has affected my daily routine, but your herbal remedies have supported my sleep patterns and reduced sensitivity. I&#39;m grateful for the natural approach. \u201D </p></div></div><div class="div7 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img${ssrRenderAttr("src", _imports_3)} alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name" data-v-e4b9d542>Emily R</p><p class="designation" data-v-e4b9d542>Verified clients</p></div></div><div class="review" data-v-e4b9d542><h4 data-v-e4b9d542>Tachycardia and joint</h4><p data-v-e4b9d542> \u201C Tachycardia and joint pain have been a constant struggle, but your herbal remedies have provided me with relief and improved my overall well-being. I appreciate the holistic approach. \u201D </p></div></div><div class="div8 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img src="https://raw.githubusercontent.com/RahulSahOfficial/testimonials_grid_section/5532c958b7d3c9b910a216b198fdd21c73112d84/images/image-daniel.jpg" alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name" data-v-e4b9d542>Jason M</p><p class="designation" data-v-e4b9d542>Verified clients</p></div></div><div class="review" data-v-e4b9d542><h4 data-v-e4b9d542>Constipation and stomach cramping.</h4><p data-v-e4b9d542> \u201C I&#39;ve suffered from constipation and stomach cramping, but your herbal products have helped regulate my digestive system and alleviate discomfort. Thank you for the natural solutions.\u201D </p></div></div><div class="div9 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img${ssrRenderAttr("src", _imports_4)} alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name" data-v-e4b9d542>Ethan S</p><p class="designation" data-v-e4b9d542>clients</p></div></div><div class="review" data-v-e4b9d542><h4 data-v-e4b9d542>Blood Pressure</h4><p data-v-e4b9d542> \u201C Living with low blood pressure and burning mouth syndrome can be frustrating, but your herbal treatments have helped regulate my blood pressure and alleviate mouth discomfort. Thank you for the natural relief. \u201D </p></div></div><div class="div10 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img${ssrRenderAttr("src", _imports_5)} alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name" data-v-e4b9d542>Olivia D</p><p class="designation" data-v-e4b9d542>clients</p></div></div><div class="review" data-v-e4b9d542><h4 data-v-e4b9d542>Body pain and difficulty breathing</h4><p data-v-e4b9d542> \u201C Body pain and difficulty breathing have been challenging, but your herbal remedies have offered me relief and improved my daily functioning. I&#39;m grateful for the natural alternatives. \u201D </p></div></div><div class="div11 eachdiv" data-v-e4b9d542><div class="userdetails" data-v-e4b9d542><div class="imgbox" data-v-e4b9d542><img${ssrRenderAttr("src", _imports_6)} alt="" data-v-e4b9d542></div><div class="detbox" data-v-e4b9d542><p class="name" data-v-e4b9d542>Samantha K</p><p class="designation" data-v-e4b9d542>clients</p></div></div><div class="review" data-v-e4b9d542><h4 data-v-e4b9d542>Lightheadedness and dizziness</h4><p data-v-e4b9d542> \u201C Lightheadedness and dizziness have made everyday tasks challenging, but your herbal treatments have provided me with relief and improved my quality of life. Thank you for the natural solutions. \u201D </p></div></div></div></div>`);
  _push(ssrRenderComponent(_component_LazyAppFooter, null, null, _parent));
  _push(`</main>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/Testimonial.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Testimonial = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-e4b9d542"]]);

export { Testimonial as default };
//# sourceMappingURL=Testimonial-ece4f6ae.mjs.map
