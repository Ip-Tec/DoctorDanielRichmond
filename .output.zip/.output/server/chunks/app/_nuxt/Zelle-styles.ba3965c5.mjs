const Zelle_vue_vue_type_style_index_0_scoped_4333a291_lang = ".st0[data-v-4333a291]{fill:#6c1cd3}";

const ZelleStyles_ba3965c5 = [Zelle_vue_vue_type_style_index_0_scoped_4333a291_lang, Zelle_vue_vue_type_style_index_0_scoped_4333a291_lang];

export { ZelleStyles_ba3965c5 as default };
//# sourceMappingURL=Zelle-styles.ba3965c5.mjs.map
