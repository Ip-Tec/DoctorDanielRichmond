import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const About_vue_vue_type_style_index_0_scoped_790705af_lang = 'main[data-v-790705af]{background:var(--lightgreen)}.about[data-v-790705af],main[data-v-790705af]{padding:1rem}.about[data-v-790705af]{-webkit-backdrop-filter:blur(10px);backdrop-filter:blur(10px);background-color:hsla(0,0%,100%,.3);border-radius:10px;margin:auto;width:80%}.about h3[data-v-790705af]{font-size:1.5rem;margin-bottom:1rem}.about p[data-v-790705af]{font-size:1rem;line-height:1.5}.about p[data-v-790705af]:after{border-radius:51% 49% 42% 58%/37% 67% 33% 63%;content:"";padding:3rem;position:relative;top:-4rem}p.glass[data-v-790705af]:after{animation:glass-move-790705af 2s linear infinite;backdrop-filter:blur(6.2px);-webkit-backdrop-filter:blur(6.2px);background:hsla(0,0%,100%,.39);border:1px solid hsla(0,0%,100%,.36);box-shadow:0 4px 30px rgba(0,0,0,.1)}@keyframes glass-move-790705af{0%{border-radius:37% 67% 33% 63%/51% 49% 42% 58%;top:-1rem}50%{border-radius:70% 30% 42% 58%/37% 39% 61% 63%;top:1rem}to{border-radius:37% 67% 33% 63%/51% 49% 42% 58%;top:-1rem}}';

const Specialization_vue_vue_type_style_index_0_scoped_590deef6_lang = ".parallax-container[data-v-590deef6]{height:500px;overflow:hidden;position:relative}.parallax-content[data-v-590deef6]{background-image:url(" + buildAssetsURL("organic-herbs-spices-wooden-bowl-generated-by-ai.330f9735.jpg") + ');background-position:50%;background-size:cover;color:var(--white);height:100%;left:0;position:fixed;top:0;width:10%;z-index:-1}.parallax-content[data-v-590deef6]:before{background:rgba(0,0,0,.3);content:"";height:100%;left:0;opacity:0;position:absolute;top:0;transform:translateZ(-1px) scale(2);transition:opacity .3s ease-in-out;width:98%}.parallax-container:hover .parallax-content[data-v-590deef6]:before{opacity:1}.parallax-content h2[data-v-590deef6]{text-align:center}';

const SSSDefault_vue_vue_type_style_index_0_scoped_58807522_lang = "span[data-v-58807522]{background-color:var(--white);display:block;margin:1rem 0;padding:2rem;width:100vw}";

const SSSDefaultStyles_e9a0fe45 = [About_vue_vue_type_style_index_0_scoped_790705af_lang, Specialization_vue_vue_type_style_index_0_scoped_590deef6_lang, SSSDefault_vue_vue_type_style_index_0_scoped_58807522_lang, SSSDefault_vue_vue_type_style_index_0_scoped_58807522_lang];

export { SSSDefaultStyles_e9a0fe45 as default };
//# sourceMappingURL=SSSDefault-styles.e9a0fe45.mjs.map
