import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const imge1 = "" + buildAssetsURL("eyewear-4071870_640.b54fb6fc.jpg");

export { imge1 as i };
//# sourceMappingURL=eyewear-4071870_640-56d5270e.mjs.map
