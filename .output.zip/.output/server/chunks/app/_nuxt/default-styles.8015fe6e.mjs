import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const default_vue_vue_type_style_index_0_scoped_f55aadf3_lang = "@import url(https://fonts.googleapis.com/css?family=Oswald:300,400,700);@import url(https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic);#main[data-v-f55aadf3]{padding:0;width:100%}svg[data-v-f55aadf3]{bottom:0;left:0;position:absolute}svg path[data-v-f55aadf3]{fill:var(--lightgreen)}.content-asset p[data-v-f55aadf3]{margin:0 auto}.breadcrumb[data-v-f55aadf3]{display:none}.margin-top-10[data-v-f55aadf3]{padding-top:10px}.margin-bot-10[data-v-f55aadf3]{padding-bottom:10px}#parallax-world-of-ugg h1[data-v-f55aadf3]{color:#000;font-size:24px;margin:0;padding:0}#parallax-world-of-ugg h1[data-v-f55aadf3],#parallax-world-of-ugg h2[data-v-f55aadf3]{font-family:Oswald,sans-serif;font-weight:400;text-transform:uppercase}#parallax-world-of-ugg h2[data-v-f55aadf3]{color:#fff;font-size:70px;letter-spacing:10px;opacity:.9;text-align:center;z-index:10}#parallax-world-of-ugg h3[data-v-f55aadf3]{color:#000;font-family:Oswald,sans-serif;font-size:14px;font-weight:400;letter-spacing:8px;line-height:0;text-transform:uppercase}#parallax-world-of-ugg p[data-v-f55aadf3]{font-size:14px;line-height:24px}#parallax-world-of-ugg p[data-v-f55aadf3],.first-character[data-v-f55aadf3]{font-family:Source Sans Pro,sans-serif;font-weight:400}.first-character[data-v-f55aadf3]{float:left;font-size:84px;line-height:64px;padding-left:3px;padding-right:8px;padding-top:4px}.sc[data-v-f55aadf3]{color:#3b8595}.ny[data-v-f55aadf3]{color:#3d3c3a}.atw[data-v-f55aadf3]{color:#c48660}#parallax-world-of-ugg .title[data-v-f55aadf3]{background:#fff;margin:0 auto;padding:60px;text-align:center}#parallax-world-of-ugg .title h1[data-v-f55aadf3]{font-size:35px;letter-spacing:8px}#parallax-world-of-ugg .block[data-v-f55aadf3]:first-child,section[data-v-f55aadf3]:nth-child(2){background:var(--lightgreen)}#parallax-world-of-ugg .block[data-v-f55aadf3]{background:#fff;margin:0 auto;padding:60px;text-align:justify;width:820px}#parallax-world-of-ugg .block-gray[data-v-f55aadf3]{background:#f2f2f2;padding:60px}#parallax-world-of-ugg .section-overlay-mask[data-v-f55aadf3]{background-color:#000;height:100%;left:0;opacity:.7;position:absolute;top:0;width:100%}#parallax-world-of-ugg .parallax-one[data-v-f55aadf3]{background-image:url(" + buildAssetsURL("benefits-ayurvedic-healing-herbs.f91aed27.jpg") + ");background-position:top}#parallax-world-of-ugg .parallax-one[data-v-f55aadf3],#parallax-world-of-ugg .parallax-two[data-v-f55aadf3]{background-attachment:fixed;background-repeat:no-repeat;background-size:cover;-moz-background-size:cover;-webkit-background-size:cover;overflow:hidden;padding-bottom:200px;padding-top:200px;position:relative;width:100%}#parallax-world-of-ugg .parallax-two[data-v-f55aadf3]{background-image:url(https://images.unsplash.com/photo-1432163230927-a32e4fd5a326?dpr=1&auto=format&fit=crop&w=1500&h=1000&q=80&cs=tinysrgb&crop=);background-position:50%}#parallax-world-of-ugg .parallax-three[data-v-f55aadf3]{background-attachment:fixed;background-image:url(https://images.unsplash.com/photo-1440688807730-73e4e2169fb8?dpr=1&auto=format&fit=crop&w=1500&h=1001&q=80&cs=tinysrgb&crop=);background-position:50%;background-repeat:no-repeat;background-size:cover;-moz-background-size:cover;-webkit-background-size:cover;overflow:hidden;padding-bottom:200px;padding-top:200px;position:relative;width:100%}#parallax-world-of-ugg .line-break[data-v-f55aadf3]{border-bottom:1px solid #000;margin:0 auto;width:150px}@media screen and (max-width:959px) and (min-width:768px){#parallax-world-of-ugg .block[data-v-f55aadf3]{padding:40px;width:620px}}@media screen and (max-width:767px){#parallax-world-of-ugg .block[data-v-f55aadf3]{width:420px}#parallax-world-of-ugg h2[data-v-f55aadf3]{font-size:30px}#parallax-world-of-ugg .block[data-v-f55aadf3]{padding:30px}#parallax-world-of-ugg .parallax-one[data-v-f55aadf3],#parallax-world-of-ugg .parallax-three[data-v-f55aadf3],#parallax-world-of-ugg .parallax-two[data-v-f55aadf3]{padding-bottom:100px;padding-top:100px}}@media screen and (max-width:479px){#parallax-world-of-ugg .block[data-v-f55aadf3]{padding:30px 15px;width:290px}}";

const defaultStyles_8015fe6e = [default_vue_vue_type_style_index_0_scoped_f55aadf3_lang, default_vue_vue_type_style_index_0_scoped_f55aadf3_lang];

export { defaultStyles_8015fe6e as default };
//# sourceMappingURL=default-styles.8015fe6e.mjs.map
