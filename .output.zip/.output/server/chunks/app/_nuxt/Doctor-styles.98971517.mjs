const Doctor_vue_vue_type_style_index_0_scoped_74068f0f_lang = ".st0[data-v-74068f0f]{fill:#000}";

const DoctorStyles_98971517 = [Doctor_vue_vue_type_style_index_0_scoped_74068f0f_lang, Doctor_vue_vue_type_style_index_0_scoped_74068f0f_lang];

export { DoctorStyles_98971517 as default };
//# sourceMappingURL=Doctor-styles.98971517.mjs.map
