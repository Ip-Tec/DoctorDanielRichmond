import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0$1 } from './Header-4d3c6d40.mjs';
import { useSSRContext, ref, mergeProps, withCtx, createTextVNode, defineAsyncComponent } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import { _ as _export_sfc, d as __nuxt_component_3, b as __nuxt_component_2 } from '../server.mjs';
import { i as imge1 } from './eyewear-4071870_640-56d5270e.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import 'unctx';
import 'vue-router';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';

const __nuxt_component_0_lazy$1 = /* @__PURE__ */ defineAsyncComponent(() => import('./Facebook-9ec2a6d3.mjs').then((m) => m.default || m));
const __nuxt_component_1_lazy$2 = /* @__PURE__ */ defineAsyncComponent(() => import('./Whatsapp-4d6c08d2.mjs').then((m) => m.default || m));
const _sfc_main$5 = {
  __name: "Contacts",
  __ssrInlineRender: true,
  setup(__props) {
    const name = ref("");
    const email = ref("");
    const message = ref("");
    const errors = ref({
      name: "",
      email: "",
      message: ""
    });
    const success = ref({
      message: ""
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_LazyIconFacebook = __nuxt_component_0_lazy$1;
      const _component_LazyIconWhatsapp = __nuxt_component_1_lazy$2;
      _push(`<main${ssrRenderAttrs(mergeProps({ id: "contacts" }, _attrs))} data-v-a59fd22c><h2 data-v-a59fd22c>Contact Us</h2><div class="contact-form" data-v-a59fd22c><form data-v-a59fd22c><div class="con-form" data-v-a59fd22c><label for="name" data-v-a59fd22c>Name</label><input type="text" name="name"${ssrRenderAttr("value", name.value)} data-v-a59fd22c><span class="error" data-v-a59fd22c>${ssrInterpolate(errors.value.name)}</span></div><div class="con-form" data-v-a59fd22c><label for="email" data-v-a59fd22c>Email</label><input type="email" name="email"${ssrRenderAttr("value", email.value)} data-v-a59fd22c><span class="error" data-v-a59fd22c>${ssrInterpolate(errors.value.email)}</span></div><div class="con-form" data-v-a59fd22c><label for="message" data-v-a59fd22c>Message</label><textarea data-v-a59fd22c>${ssrInterpolate(message.value)}</textarea><span class="error" data-v-a59fd22c>${ssrInterpolate(errors.value.message)}</span></div><p data-v-a59fd22c>${ssrInterpolate(success.value.message)}</p><button type="submit" data-v-a59fd22c>Send</button></form><div class="info" data-v-a59fd22c><p data-v-a59fd22c>Connect with a Doctor</p><div class="icon" data-v-a59fd22c><i data-v-a59fd22c><a href="https://www.facebook.com/Doctordanielrichmond?mibextid=LQQJ4d " target="_blank" data-v-a59fd22c>`);
      _push(ssrRenderComponent(_component_LazyIconFacebook, {
        width: "30px",
        height: "30px",
        fill: "none"
      }, null, _parent));
      _push(`</a></i><i data-v-a59fd22c><a href="https://wa.me/18482570968" target="_blank" rel="noopener noreferrer" data-v-a59fd22c>`);
      _push(ssrRenderComponent(_component_LazyIconWhatsapp, {
        width: "30px",
        height: "30px"
      }, null, _parent));
      _push(`</a></i></div></div></div></main>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/app/Contacts.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-a59fd22c"]]);
const __nuxt_component_0_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./Venmo-b6456055.mjs').then((m) => m.default || m));
const __nuxt_component_1_lazy$1 = /* @__PURE__ */ defineAsyncComponent(() => import('./Zelle-e0c5d1c8.mjs').then((m) => m.default || m));
const __nuxt_component_2_lazy$1 = /* @__PURE__ */ defineAsyncComponent(() => import('./Paypal-496e2b08.mjs').then((m) => m.default || m));
const __nuxt_component_3_lazy$1 = /* @__PURE__ */ defineAsyncComponent(() => import('./Squarecash-151e96ca.mjs').then((m) => m.default || m));
const _sfc_main$4 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_LazyIconVenmo = __nuxt_component_0_lazy;
  const _component_LazyIconZelle = __nuxt_component_1_lazy$1;
  const _component_LazyIconPaypal = __nuxt_component_2_lazy$1;
  const _component_LazyIconSquarecash = __nuxt_component_3_lazy$1;
  _push(`<div${ssrRenderAttrs(_attrs)} data-v-db59c7e7><div class="text" data-v-db59c7e7><h1 data-v-db59c7e7>payment</h1><p data-v-db59c7e7>This Are Our Payment Platforms</p></div><div class="icon" data-v-db59c7e7><li data-v-db59c7e7>`);
  _push(ssrRenderComponent(_component_LazyIconVenmo, {
    width: "50px",
    height: "50px"
  }, null, _parent));
  _push(`</li><li data-v-db59c7e7>`);
  _push(ssrRenderComponent(_component_LazyIconZelle, {
    width: "50px",
    height: "50px"
  }, null, _parent));
  _push(`</li><li data-v-db59c7e7>`);
  _push(ssrRenderComponent(_component_LazyIconPaypal, {
    width: "50px",
    height: "50px"
  }, null, _parent));
  _push(`</li><li data-v-db59c7e7>`);
  _push(ssrRenderComponent(_component_LazyIconSquarecash, {
    width: "50px",
    height: "50px"
  }, null, _parent));
  _push(`</li></div></div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/app/Payment.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_7 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-db59c7e7"]]);
const _sfc_main$3 = {
  __name: "Leftarrow",
  __ssrInlineRender: true,
  emits: {
    fill: {
      type: [String],
      default: "#2dea75"
    },
    height: {
      type: [String],
      default: "3rem"
    },
    width: {
      type: [String],
      default: "3rem"
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<svg${ssrRenderAttrs(mergeProps({
        width: _ctx.width,
        height: _ctx.height,
        viewBox: "0 0 1024 1024",
        class: "icon",
        version: "1.1",
        xmlns: "http://www.w3.org/2000/svg"
      }, _attrs))}><path d="M768 903.232l-50.432 56.768L256 512l461.568-448 50.432 56.768L364.928 512z" fill="#faf6f6"></path></svg>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/icon/Leftarrow.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const _sfc_main$2 = {
  __name: "Rightarrow",
  __ssrInlineRender: true,
  emits: {
    fill: {
      type: [String],
      default: "#faf6f6"
    },
    width: {
      type: [String],
      default: "3rem"
    },
    height: {
      type: [String],
      default: "3rem"
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<svg${ssrRenderAttrs(mergeProps({
        width: _ctx.width,
        height: _ctx.height,
        viewBox: "0 0 1024 1024",
        class: "icon",
        version: "1.1",
        xmlns: "http://www.w3.org/2000/svg"
      }, _attrs))}><path d="M256 120.768L306.432 64 768 512l-461.568 448L256 903.232 659.072 512z" fill="#faf6f6"></path></svg>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/icon/Rightarrow.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const imge = "" + buildAssetsURL("face-5084530_1280.ba9eb88c.jpg");
const imge2 = "" + buildAssetsURL("guy-3237859_640.f3ca8300.png");
const imge3 = "" + buildAssetsURL("model-2333408_640.84206f94.jpg");
const imge4 = "" + buildAssetsURL("boy-2119178_640.2b3d272f.jpg");
const _sfc_main$1 = {
  __name: "Testimonial",
  __ssrInlineRender: true,
  setup(__props) {
    ref(0);
    const currentIndex = ref(0);
    currentIndex.value = 0;
    ref(false);
    ref(0);
    const testimonials = [
      {
        name: "Sarah M",
        review: "I have been using herbal remedies from your website for a few months now, and I must say the results are amazing. My overall health has improved, and I feel more energized.",
        imageUrl: imge
      },
      {
        name: "Michael W",
        review: "I was skeptical at first, but after trying the herbal products recommended by your team, my chronic pain has reduced significantly. Thank you for providing natural alternatives that actually work!",
        imageUrl: imge1
      },
      {
        name: "Alex B",
        review: "I've tried various treatments for my chronic migraines, but your herbal remedies have provided me with the most relief. I'm grateful for the holistic approach and the positive impact it has had on my life.",
        imageUrl: imge2
      },
      {
        name: "Emma T",
        review: "The herbal treatments I received from your website have helped me manage my stress levels and improve my sleep quality. I feel more balanced and calm now.",
        imageUrl: imge3
      },
      {
        name: "Mark D",
        review: "I've struggled with digestive issues for years, and your herbal remedies have provided me with relief like no other. My digestion has improved, and I no longer experience frequent discomfort.",
        imageUrl: imge4
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_IconLeftarrow = __nuxt_component_0;
      const _component_IconRightarrow = __nuxt_component_1;
      const _component_NuxtLink = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))} data-v-00a86e42><div class="header" data-v-00a86e42><h2 data-v-00a86e42>Testimonial</h2><h1 data-v-00a86e42>Honest Review of Our Clients</h1></div><div class="icon" data-v-00a86e42><i class="arrow arrow-left" data-v-00a86e42>`);
      _push(ssrRenderComponent(_component_IconLeftarrow, {
        width: "3rem",
        height: "3rem"
      }, null, _parent));
      _push(`</i><i class="arrow arrow-right" data-v-00a86e42>`);
      _push(ssrRenderComponent(_component_IconRightarrow, {
        width: "3rem",
        height: "3rem"
      }, null, _parent));
      _push(`</i></div><div class="slider" data-v-00a86e42><div class="slider__inner" data-v-00a86e42><!--[-->`);
      ssrRenderList(testimonials, (testimonial, index2) => {
        _push(`<div class="${ssrRenderClass([{ visible: currentIndex.value === index2 }, "contents"])}" data-v-00a86e42><i class="image" data-v-00a86e42><img${ssrRenderAttr("src", testimonial.imageUrl)}${ssrRenderAttr("alt", testimonial.name)} width="30rem" data-v-00a86e42></i><h2 class="name" data-v-00a86e42>${ssrInterpolate(testimonial.name)}</h2><p class="text" data-v-00a86e42>${ssrInterpolate(testimonial.review)}</p></div>`);
      });
      _push(`<!--]--></div></div>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/Testimonial",
        class: "link"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`See More`);
          } else {
            return [
              createTextVNode("See More")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/app/Testimonial.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_8 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-00a86e42"]]);
const __nuxt_component_1_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./Delivery-55ddd28d.mjs').then((m) => m.default || m));
const __nuxt_component_2_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./Certified-0578f3ee.mjs').then((m) => m.default || m));
const __nuxt_component_3_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./Doctor-2fd4e74e.mjs').then((m) => m.default || m));
const __nuxt_component_4_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./Doctors-9e24fbbd.mjs').then((m) => m.default || m));
const __nuxt_component_5_lazy = /* @__PURE__ */ defineAsyncComponent(() => import('./Medicine-31edc54a.mjs').then((m) => m.default || m));
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    ref([
      "",
      "Our commitment to quality and efficacy drives us to source the finest organic herbs and botanicals from trusted suppliers. We follow strict quality control measures to ensure the purity and potency of our herbal formulations.",
      "Whether you are seeking relief from a specific health condition or striving to maintain optimal wellness, we are here to guide you on your healing journey. We combine traditional wisdom with scientific knowledge to provide safe, effective, and sustainable solutions for your health concerns."
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_AppHeader = __nuxt_component_0$1;
      const _component_LazyIconDelivery = __nuxt_component_1_lazy;
      const _component_LazyIconCertified = __nuxt_component_2_lazy;
      const _component_LazyIconDoctor = __nuxt_component_3_lazy;
      const _component_LazyIconDoctors = __nuxt_component_4_lazy;
      const _component_LazyIconMedicine = __nuxt_component_5_lazy;
      const _component_AppContacts = __nuxt_component_6;
      const _component_AppPayment = __nuxt_component_7;
      const _component_AppTestimonial = __nuxt_component_8;
      const _component_AppFooter = __nuxt_component_3;
      _push(`<div${ssrRenderAttrs(mergeProps({ id: "parallax-world-of-ugg" }, _attrs))} data-v-11335aab><section data-v-11335aab>`);
      _push(ssrRenderComponent(_component_AppHeader, null, null, _parent));
      _push(`</section><section id="home" data-v-11335aab><div class="parallax-one home" data-v-11335aab><h2 data-v-11335aab> Hi I&#39;m <strong data-v-11335aab>Doctor Daniel Richmond</strong></h2><svg class="wave" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" data-v-11335aab><path fill-opacity="1" d="M0,224L21.8,229.3C43.6,235,87,245,131,229.3C174.5,213,218,171,262,138.7C305.5,107,349,85,393,112C436.4,139,480,213,524,245.3C567.3,277,611,267,655,250.7C698.2,235,742,213,785,176C829.1,139,873,85,916,80C960,75,1004,117,1047,128C1090.9,139,1135,117,1178,90.7C1221.8,64,1265,32,1309,16C1352.7,0,1396,0,1418,0L1440,0L1440,320L1418.2,320C1396.4,320,1353,320,1309,320C1265.5,320,1222,320,1178,320C1134.5,320,1091,320,1047,320C1003.6,320,960,320,916,320C872.7,320,829,320,785,320C741.8,320,698,320,655,320C610.9,320,567,320,524,320C480,320,436,320,393,320C349.1,320,305,320,262,320C218.2,320,175,320,131,320C87.3,320,44,320,22,320L0,320Z" data-v-11335aab></path></svg></div></section><section id="aboutInfo" data-v-11335aab><div class="aboutInfo" data-v-11335aab><div class="aboutInfo-p" data-v-11335aab><i data-v-11335aab>`);
      _push(ssrRenderComponent(_component_LazyIconDelivery, {
        fill: "white",
        height: "100px",
        width: "100px"
      }, null, _parent));
      _push(`</i><h3 data-v-11335aab>We Deliver</h3><p data-v-11335aab>Fast and Reliable Delivery Service</p><p data-v-11335aab>Nationwide Coverage</p><p data-v-11335aab>Timely Delivery to Your Doorstep</p></div><div class="aboutInfo-p" data-v-11335aab><i data-v-11335aab>`);
      _push(ssrRenderComponent(_component_LazyIconCertified, {
        fill: "#111",
        height: "50px",
        width: "50px"
      }, null, _parent));
      _push(`</i><h3 data-v-11335aab>Certified Medicine</h3><p data-v-11335aab>Quality Assurance for all Medicine</p><p data-v-11335aab>Rigorous Testing for Safety and Efficacy</p><p data-v-11335aab>Trusted and Genuine Medicines</p></div><div class="aboutInfo-p" data-v-11335aab><i data-v-11335aab>`);
      _push(ssrRenderComponent(_component_LazyIconDoctor, {
        fill: "#000000",
        height: "50px",
        width: "50px"
      }, null, _parent));
      _push(`</i><h3 data-v-11335aab>Professional Team</h3><p data-v-11335aab>Expert Pharmacists for Reliable Advice</p><p data-v-11335aab>Personalized Service for Your Needs</p><p data-v-11335aab>Committed to Patient Care and Well-being</p></div></div></section><section id="about" data-v-11335aab><div class="block about" data-v-11335aab><h2 class="full-width" data-v-11335aab>About Us</h2><div class="about-p" data-v-11335aab><div class="mission" data-v-11335aab><p class="glass" data-v-11335aab> Our primary mission is to ensure a healthy good living life by making herbal medicine available to the public powerful and effective. We use only certified natural organic herbs and wild harvested quality tested ingredients to produce </p>`);
      _push(ssrRenderComponent(_component_LazyIconDoctors, {
        width: "400px",
        height: "400px"
      }, null, _parent));
      _push(`</div><div class="we" data-v-11335aab>`);
      _push(ssrRenderComponent(_component_LazyIconMedicine, {
        width: "400px",
        height: "400px"
      }, null, _parent));
      _push(`<p class="glass" data-v-11335aab> We understand disease at a level beyond the superficial symptoms and strive to find a permanent resolution. Together with the patient, we aim to bring about a state of absolute health in everyone who consults us. we have studied the natural properties of natural herbs , their remarkable benefits, and developed a unique range of drops, capsules, bottle herbs and dried herbs. We have employed scientific testing methods and modern extraction processes to ensure the benefits of the herbs remain intact, all this at a very good price and excellent quality. We ship worldwide. </p></div></div><p class="line-break margin-top-10" data-v-11335aab></p></div></section><section id="contacts" data-v-11335aab><div class="parallax-two contacts" data-v-11335aab>`);
      _push(ssrRenderComponent(_component_AppContacts, null, null, _parent));
      _push(`</div></section><section id="payment" data-v-11335aab><div class="payment" data-v-11335aab>`);
      _push(ssrRenderComponent(_component_AppPayment, null, null, _parent));
      _push(`</div></section><section id="testimony" data-v-11335aab><div class="parallax-three testimony" data-v-11335aab>`);
      _push(ssrRenderComponent(_component_AppTestimonial, null, null, _parent));
      _push(`</div></section><section id="footer" data-v-11335aab><div class="footer" data-v-11335aab>`);
      _push(ssrRenderComponent(_component_AppFooter, null, null, _parent));
      _push(`</div></section></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-11335aab"]]);

export { index as default };
//# sourceMappingURL=index-f4779d90.mjs.map
