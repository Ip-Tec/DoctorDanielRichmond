import { _ as __nuxt_component_0 } from './Header-4d3c6d40.mjs';
import { useSSRContext, resolveComponent, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc, d as __nuxt_component_3 } from '../server.mjs';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'vue-router';
import 'h3';
import 'ufo';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'defu';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';

const _sfc_main$2 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  _push(`<main${ssrRenderAttrs(mergeProps({ id: "about" }, _attrs))} data-v-790705af><div class="about" data-v-790705af><h3 data-v-790705af>About Us</h3><p class="glass" data-v-790705af> Welcome to Herbal Doctor, where natural healing meets modern medicine. Our mission is to provide holistic and personalized healthcare solutions using the power of herbal remedies and traditional medicine. </p><p class="glass" data-v-790705af> With years of experience and a deep understanding of the healing properties of herbs, our team of dedicated herbal doctors strives to promote optimal health and well-being for our patients. We believe in the body&#39;s innate ability to heal itself and aim to support and enhance this natural healing process. </p><p class="glass" data-v-790705af> At Herbal Doctor, we take a comprehensive and personalized approach to healthcare. Our herbal treatments are tailored to each individual&#39;s unique needs, addressing the underlying causes of health issues rather than just the symptoms. </p><p class="glass" data-v-790705af> Our commitment to quality and efficacy drives us to source the finest organic herbs and botanicals from trusted suppliers. We follow strict quality control measures to ensure the purity and potency of our herbal formulations. </p><p class="glass" data-v-790705af> Whether you are seeking relief from a specific health condition or striving to maintain optimal wellness, our herbal doctors are here to guide you on your healing journey. We combine traditional wisdom with scientific knowledge to provide safe, effective, and sustainable solutions for your health concerns. </p><p class="glass" data-v-790705af> Experience the power of nature and embark on a path of holistic healing with Herbal Doctor. We are dedicated to helping you achieve vibrant health and a balanced lifestyle. </p></div></main>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/app/About.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$2], ["__scopeId", "data-v-790705af"]]);
const _sfc_main$1 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)} data-v-590deef6><div class="parallax-container" data-v-590deef6><div class="parallax-content" data-v-590deef6><h2 data-v-590deef6>Specialization</h2><div class="content" data-v-590deef6><div class="text-card" data-v-590deef6><p data-v-590deef6>Lorem ipsum dolor sit amet consectetur adipisicing elit. Harum fuga error repellendus quo deserunt at.</p></div><div class="img-card" data-v-590deef6></div></div></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/app/Specialization.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-590deef6"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_AppHeader = __nuxt_component_0;
  const _component_AppAbout = __nuxt_component_1;
  const _component_AppSpecialization = __nuxt_component_2;
  const _component_ContactUs = resolveComponent("ContactUs");
  const _component_AppFooter = __nuxt_component_3;
  _push(`<div${ssrRenderAttrs(_attrs)} data-v-58807522>`);
  _push(ssrRenderComponent(_component_AppHeader, null, null, _parent));
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(ssrRenderComponent(_component_AppAbout, null, null, _parent));
  _push(ssrRenderComponent(_component_AppSpecialization, null, null, _parent));
  _push(`<span data-v-58807522></span>`);
  _push(ssrRenderComponent(_component_ContactUs, null, null, _parent));
  _push(ssrRenderComponent(_component_AppFooter, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/SSSDefault.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const SSSDefault = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-58807522"]]);

export { SSSDefault as default };
//# sourceMappingURL=SSSDefault-fb25d3fb.mjs.map
