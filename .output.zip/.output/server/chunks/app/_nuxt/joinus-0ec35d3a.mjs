import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { ref, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'http-graceful-shutdown';
import 'unctx';
import 'vue-router';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';

const _imports_0 = "" + buildAssetsURL("benefits-ayurvedic-healing-herbs.f91aed27.jpg");
const _sfc_main = {
  __name: "joinus",
  __ssrInlineRender: true,
  setup(__props) {
    ref("contacts");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<main${ssrRenderAttrs(mergeProps({ id: "home" }, _attrs))} data-v-b1e564ff><div class="image-container" data-v-b1e564ff><img${ssrRenderAttr("src", _imports_0)} alt="" srcset="" data-v-b1e564ff><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" data-v-b1e564ff><path fill-opacity="1" d="M0,224L21.8,229.3C43.6,235,87,245,131,229.3C174.5,213,218,171,262,138.7C305.5,107,349,85,393,112C436.4,139,480,213,524,245.3C567.3,277,611,267,655,250.7C698.2,235,742,213,785,176C829.1,139,873,85,916,80C960,75,1004,117,1047,128C1090.9,139,1135,117,1178,90.7C1221.8,64,1265,32,1309,16C1352.7,0,1396,0,1418,0L1440,0L1440,320L1418.2,320C1396.4,320,1353,320,1309,320C1265.5,320,1222,320,1178,320C1134.5,320,1091,320,1047,320C1003.6,320,960,320,916,320C872.7,320,829,320,785,320C741.8,320,698,320,655,320C610.9,320,567,320,524,320C480,320,436,320,393,320C349.1,320,305,320,262,320C218.2,320,175,320,131,320C87.3,320,44,320,22,320L0,320Z" data-v-b1e564ff></path></svg><div class="landing-content" data-v-b1e564ff><div class="content" data-v-b1e564ff><div class="text-slider" data-v-b1e564ff><div class="slide" data-v-b1e564ff><h3 data-v-b1e564ff> Health is not everything, but without health, everything is nothing. </h3></div><div class="slide" data-v-b1e564ff><h3 data-v-b1e564ff>The right herb at the right time can do wonders.</h3></div><div class="slide" data-v-b1e564ff><h3 data-v-b1e564ff>The body is a temple, and we should treat it as such.</h3></div></div></div><button type="button" data-v-b1e564ff>Contects Us</button></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/joinus.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const joinus = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-b1e564ff"]]);

export { joinus as default };
//# sourceMappingURL=joinus-0ec35d3a.mjs.map
