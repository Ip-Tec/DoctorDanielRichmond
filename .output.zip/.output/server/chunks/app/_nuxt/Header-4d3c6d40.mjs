import { ref, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderClass } from 'vue/server-renderer';
import { _ as _export_sfc, e as _imports_0 } from '../server.mjs';

const _sfc_main = {
  __name: "Header",
  __ssrInlineRender: true,
  setup(__props) {
    const activeSection = ref("home");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs(mergeProps({ class: "fixed-header" }, _attrs))} data-v-72ee2d37><div data-v-72ee2d37><img${ssrRenderAttr("src", _imports_0)} alt="" data-v-72ee2d37></div><ul data-v-72ee2d37><li class="${ssrRenderClass({ active: activeSection.value === "home" })}" data-v-72ee2d37><p data-v-72ee2d37>Home</p></li><li class="${ssrRenderClass({ active: activeSection.value === "about" })}" data-v-72ee2d37><p data-v-72ee2d37>About</p></li><li class="${ssrRenderClass({ active: activeSection.value === "contacts" })}" data-v-72ee2d37><p data-v-72ee2d37>Contacts</p></li><li class="${ssrRenderClass({ active: activeSection.value === "testimony" })}" data-v-72ee2d37><p data-v-72ee2d37>Testimony</p></li></ul></nav>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/app/Header.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-72ee2d37"]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=Header-4d3c6d40.mjs.map
