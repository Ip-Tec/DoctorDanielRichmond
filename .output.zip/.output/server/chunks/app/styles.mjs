const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.3b97bc10.mjs').then(interopDefault),
  "pages/Testimonial.vue": () => import('./_nuxt/Testimonial-styles.81fa1918.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.b205c949.mjs').then(interopDefault),
  "pages/joinus.vue": () => import('./_nuxt/joinus-styles.bbb42646.mjs').then(interopDefault),
  "components/icon/Doctor.vue": () => import('./_nuxt/Doctor-styles.98971517.mjs').then(interopDefault),
  "components/icon/Zelle.vue": () => import('./_nuxt/Zelle-styles.ba3965c5.mjs').then(interopDefault),
  "layouts/SSSDefault.vue": () => import('./_nuxt/SSSDefault-styles.e9a0fe45.mjs').then(interopDefault),
  "layouts/SSSSCloan.vue": () => import('./_nuxt/SSSSCloan-styles.b0d5d4cc.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./_nuxt/default-styles.8015fe6e.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
